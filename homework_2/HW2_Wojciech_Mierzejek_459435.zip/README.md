Link to Colab version:
https://colab.research.google.com/drive/15iGHmRvbpF3ccb3kmObdXaFDdN2LKyFp?usp=sharing
Expected runtime: ~9 minutes on Colab T4 GPU.

Note: I don't know why, but this notebook on Colab may give even ~15 p.p. lower scores than when I had run it locally on my computer. 
Perhaps this is due some version diferences of some packages, or `set_seed()` function doesn't fully handle every bit of randomness in this code.